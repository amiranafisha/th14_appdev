﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH14_Amira_Nafisha_Tsaqifa
{
    public partial class InsertMatch_Form : Form
    {
        public InsertMatch_Form()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter mySqlDataAdapter;
        string query;
        DataTable dtMatch;
        DataTable dgv = new DataTable();

        private void dateTimePicke_Matchdate_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = dateTimePicker_MatchDate.Value;
            DateTime minDate = new DateTime(2016, 2, 14);

            if (selectedDate < minDate)
            {
                MessageBox.Show("Tanggal yang dipilih harus setelah tanggal minimum (14 Februari 2016).", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string selectedYear = selectedDate.Year.ToString();
                sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=5415956340Ab;database=premier_league;");
                sqlConnect.Open();

                string countQuery = "select count(*) from `match` where year(match_date) = @year";
                sqlCommand = new MySqlCommand(countQuery, sqlConnect);
                sqlCommand.Parameters.AddWithValue("@year", selectedYear);

                int matchCount = Convert.ToInt32(sqlCommand.ExecuteScalar());
                sqlConnect.Close();

                string matchID = selectedYear + (matchCount + 1).ToString("D3");
                textBox_MatchID.Text = matchID;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi Kesalahan: " + ex.Message);
            }
        }

        private void InsertMatch_Form_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=5415956340Ab;database=premier_league;");
            sqlConnect.Open();

            comboBox_TeamHome.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_TeamAway.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Team.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Player.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Type.DropDownStyle = ComboBoxStyle.DropDownList;

            dtMatch = new DataTable();
            query = "select distinct t.team_name from team t join `match` m on t.team_id = m.team_home";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            mySqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            mySqlDataAdapter.Fill(dtMatch);

            for (int i = 0; i < dtMatch.Rows.Count; i++)
            {
                comboBox_TeamHome.Items.Add(dtMatch.Rows[i][0].ToString());
            }

            dtMatch = new DataTable();
            query = "select distinct t.team_name from team t join `match` m on t.team_id = m.team_away";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            mySqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            mySqlDataAdapter.Fill(dtMatch);

            for (int i = 0; i < dtMatch.Rows.Count; i++)
            {
                comboBox_TeamAway.Items.Add(dtMatch.Rows[i][0].ToString());
            }

            dgv.Columns.Add("Minute");
            dgv.Columns.Add("Team");
            dgv.Columns.Add("Player");
            dgv.Columns.Add("Type");

            dataGridView_InsertMatch.DataSource = dgv;

            comboBox_Type.Items.Add("GO");
            comboBox_Type.Items.Add("GP");
            comboBox_Type.Items.Add("GW");
            comboBox_Type.Items.Add("CR");
            comboBox_Type.Items.Add("CY");
            comboBox_Type.Items.Add("PM");
        }

        private void comboBox_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_TeamHome.Text == comboBox_TeamAway.Text)
            {
                MessageBox.Show("Team Home dan Team Away tidak boleh kembar!");
            }
            UpdateTeams();
        }

        private void comboBox_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_TeamHome.Text == comboBox_TeamAway.Text)
            {
                MessageBox.Show("Team Home dan Team Away tidak boleh kembar!");
            }
            UpdateTeams();
        }

        private void UpdateTeams()
        {
            comboBox_Team.Items.Clear();
            comboBox_Team.Items.Add(comboBox_TeamHome.Text);
            comboBox_Team.Items.Add(comboBox_TeamAway.Text);
        }

        private void comboBox_Team_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            comboBox_Player.Items.Clear();

            try
            {
                sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=5415956340Ab;database=premier_league;");
                sqlConnect.Open();

                query = "select p.player_name from player p join team t on p.team_id = t.team_id where t.team_name = @teamName";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlCommand.Parameters.AddWithValue("@teamName", comboBox_Team.Text);

                dtMatch = new DataTable();
                mySqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                mySqlDataAdapter.Fill(dtMatch);

                for (int i = 0; i < dtMatch.Rows.Count; i++)
                {
                    comboBox_Player.Items.Add(dtMatch.Rows[i][0].ToString());
                }
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi Kesalahan: " + ex.Message);
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (comboBox_Team.SelectedIndex == -1 || comboBox_Player.SelectedIndex == -1 || comboBox_Type.SelectedIndex == -1 || string.IsNullOrEmpty(textBox_Minute.Text))
            {
                MessageBox.Show("Lengkapi semuanya terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedMinute = textBox_Minute.Text;
            string selectedTeam = comboBox_Team.SelectedItem.ToString();
            string selectedPlayer = comboBox_Player.SelectedItem.ToString();
            string selectedType = comboBox_Type.SelectedItem.ToString();

            dgv.Rows.Add(selectedMinute, selectedTeam, selectedPlayer, selectedType);

            dataGridView_InsertMatch.ClearSelection();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dataGridView_InsertMatch.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView_InsertMatch.SelectedRows)
                {
                    dataGridView_InsertMatch.Rows.Remove(row);
                }
            }
            else
            {
                MessageBox.Show("Pilih baris yang ingin dihapus terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (DataLengkap())
                {
                    TambahDataMatch();
                    TambahDataDMatch();

                    MessageBox.Show("Data berhasil ditambahkan.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    BersihkanInputan();
                }
                else
                {
                    MessageBox.Show("Lengkapi semua data terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi Kesalahan: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool DataLengkap()
        {
            if (comboBox_TeamHome.SelectedIndex == -1 || comboBox_TeamAway.SelectedIndex == -1 || comboBox_Player.SelectedIndex == -1 || comboBox_Type.SelectedIndex == -1)
            {
                return false;
            }
            return true;
        }

        private void TambahDataMatch()
        {
            try
            {
                sqlConnect.Open();

                string teamHome = comboBox_TeamHome.SelectedItem.ToString();
                string teamAway = comboBox_TeamAway.SelectedItem.ToString();
                string matchDate = dateTimePicker_MatchDate.Value.ToString("yyyy-MM-dd");

                string insertQuery = "insert into `match` (team_home, team_away, match_date) values (@teamHome, @teamAway, @matchDate)";
                sqlCommand = new MySqlCommand(insertQuery, sqlConnect);
                sqlCommand.Parameters.AddWithValue("@teamHome", teamHome);
                sqlCommand.Parameters.AddWithValue("@teamAway", teamAway);
                sqlCommand.Parameters.AddWithValue("@matchDate", matchDate);

                sqlCommand.ExecuteNonQuery();

                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Gagal menambahkan data ke tabel Match: " + ex.Message);
            }
        }

        private void TambahDataDMatch()
        {
            try
            {
                sqlConnect.Open();

                string selectMatchIDQuery = "select max(match_id) FROM `match`";
                sqlCommand = new MySqlCommand(selectMatchIDQuery, sqlConnect);
                int matchID = Convert.ToInt32(sqlCommand.ExecuteScalar());


                foreach (DataGridViewRow row in dataGridView_InsertMatch.Rows)
                {
                    string minute = row.Cells["Minute"].Value.ToString();
                    string team = row.Cells["Team"].Value.ToString();
                    string player = row.Cells["Player"].Value.ToString();
                    string type = row.Cells["Type"].Value.ToString();

                    string insertDMatchQuery = "insert into dmatch (match_id, minute, team, player, type) values (@matchID, @team, @player, @type)";
                    sqlCommand = new MySqlCommand(insertDMatchQuery, sqlConnect);
                    sqlCommand.Parameters.AddWithValue("@matchID", matchID);
                    sqlCommand.Parameters.AddWithValue("@minute", minute);
                    sqlCommand.Parameters.AddWithValue("@team", team);
                    sqlCommand.Parameters.AddWithValue("@player", player);
                    sqlCommand.Parameters.AddWithValue("@type", type);

                    sqlCommand.ExecuteNonQuery();
                }

                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Gagal menambahkan data ke tabel Dmatch: " + ex.Message);
            }
        }

        private void BersihkanInputan()
        {
            comboBox_TeamHome.SelectedIndex = -1;
            comboBox_TeamAway.SelectedIndex = -1;
            comboBox_Player.SelectedIndex = -1;
            comboBox_Type.SelectedIndex = -1;
            dgv.Rows.Clear();
        }
    }
}
