﻿namespace TH14_Amira_Nafisha_Tsaqifa
{
    partial class InsertMatch_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_MatchID = new System.Windows.Forms.Label();
            this.lb_TeamHome = new System.Windows.Forms.Label();
            this.lb_MatchDate = new System.Windows.Forms.Label();
            this.lb_TeamAway = new System.Windows.Forms.Label();
            this.textBox_MatchID = new System.Windows.Forms.TextBox();
            this.comboBox_TeamHome = new System.Windows.Forms.ComboBox();
            this.comboBox_TeamAway = new System.Windows.Forms.ComboBox();
            this.dataGridView_InsertMatch = new System.Windows.Forms.DataGridView();
            this.lb_Minute = new System.Windows.Forms.Label();
            this.lb_Team = new System.Windows.Forms.Label();
            this.lb_Player = new System.Windows.Forms.Label();
            this.lb_Type = new System.Windows.Forms.Label();
            this.textBox_Minute = new System.Windows.Forms.TextBox();
            this.comboBox_Team = new System.Windows.Forms.ComboBox();
            this.comboBox_Player = new System.Windows.Forms.ComboBox();
            this.comboBox_Type = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Insert = new System.Windows.Forms.Button();
            this.dateTimePicker_MatchDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_InsertMatch)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_MatchID
            // 
            this.lb_MatchID.AutoSize = true;
            this.lb_MatchID.Location = new System.Drawing.Point(13, 29);
            this.lb_MatchID.Name = "lb_MatchID";
            this.lb_MatchID.Size = new System.Drawing.Size(74, 20);
            this.lb_MatchID.TabIndex = 0;
            this.lb_MatchID.Text = "Match ID";
            // 
            // lb_TeamHome
            // 
            this.lb_TeamHome.AutoSize = true;
            this.lb_TeamHome.Location = new System.Drawing.Point(13, 74);
            this.lb_TeamHome.Name = "lb_TeamHome";
            this.lb_TeamHome.Size = new System.Drawing.Size(96, 20);
            this.lb_TeamHome.TabIndex = 1;
            this.lb_TeamHome.Text = "Team Home";
            // 
            // lb_MatchDate
            // 
            this.lb_MatchDate.AutoSize = true;
            this.lb_MatchDate.Location = new System.Drawing.Point(393, 29);
            this.lb_MatchDate.Name = "lb_MatchDate";
            this.lb_MatchDate.Size = new System.Drawing.Size(92, 20);
            this.lb_MatchDate.TabIndex = 2;
            this.lb_MatchDate.Text = "Match Date";
            // 
            // lb_TeamAway
            // 
            this.lb_TeamAway.AutoSize = true;
            this.lb_TeamAway.Location = new System.Drawing.Point(393, 74);
            this.lb_TeamAway.Name = "lb_TeamAway";
            this.lb_TeamAway.Size = new System.Drawing.Size(91, 20);
            this.lb_TeamAway.TabIndex = 3;
            this.lb_TeamAway.Text = "Team Away";
            // 
            // textBox_MatchID
            // 
            this.textBox_MatchID.Enabled = false;
            this.textBox_MatchID.Location = new System.Drawing.Point(124, 26);
            this.textBox_MatchID.Name = "textBox_MatchID";
            this.textBox_MatchID.Size = new System.Drawing.Size(171, 26);
            this.textBox_MatchID.TabIndex = 4;
            // 
            // comboBox_TeamHome
            // 
            this.comboBox_TeamHome.FormattingEnabled = true;
            this.comboBox_TeamHome.Location = new System.Drawing.Point(124, 66);
            this.comboBox_TeamHome.Name = "comboBox_TeamHome";
            this.comboBox_TeamHome.Size = new System.Drawing.Size(171, 28);
            this.comboBox_TeamHome.TabIndex = 5;
            this.comboBox_TeamHome.SelectedIndexChanged += new System.EventHandler(this.comboBox_TeamHome_SelectedIndexChanged);
            // 
            // comboBox_TeamAway
            // 
            this.comboBox_TeamAway.FormattingEnabled = true;
            this.comboBox_TeamAway.Location = new System.Drawing.Point(511, 66);
            this.comboBox_TeamAway.Name = "comboBox_TeamAway";
            this.comboBox_TeamAway.Size = new System.Drawing.Size(171, 28);
            this.comboBox_TeamAway.TabIndex = 7;
            this.comboBox_TeamAway.SelectedIndexChanged += new System.EventHandler(this.comboBox_TeamAway_SelectedIndexChanged);
            // 
            // dataGridView_InsertMatch
            // 
            this.dataGridView_InsertMatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_InsertMatch.Location = new System.Drawing.Point(17, 152);
            this.dataGridView_InsertMatch.Name = "dataGridView_InsertMatch";
            this.dataGridView_InsertMatch.RowHeadersVisible = false;
            this.dataGridView_InsertMatch.RowHeadersWidth = 62;
            this.dataGridView_InsertMatch.RowTemplate.Height = 28;
            this.dataGridView_InsertMatch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_InsertMatch.Size = new System.Drawing.Size(567, 267);
            this.dataGridView_InsertMatch.TabIndex = 8;
            // 
            // lb_Minute
            // 
            this.lb_Minute.AutoSize = true;
            this.lb_Minute.Location = new System.Drawing.Point(612, 178);
            this.lb_Minute.Name = "lb_Minute";
            this.lb_Minute.Size = new System.Drawing.Size(57, 20);
            this.lb_Minute.TabIndex = 9;
            this.lb_Minute.Text = "Minute";
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(612, 222);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(49, 20);
            this.lb_Team.TabIndex = 10;
            this.lb_Team.Text = "Team";
            // 
            // lb_Player
            // 
            this.lb_Player.AutoSize = true;
            this.lb_Player.Location = new System.Drawing.Point(612, 267);
            this.lb_Player.Name = "lb_Player";
            this.lb_Player.Size = new System.Drawing.Size(52, 20);
            this.lb_Player.TabIndex = 11;
            this.lb_Player.Text = "Player";
            // 
            // lb_Type
            // 
            this.lb_Type.AutoSize = true;
            this.lb_Type.Location = new System.Drawing.Point(612, 306);
            this.lb_Type.Name = "lb_Type";
            this.lb_Type.Size = new System.Drawing.Size(43, 20);
            this.lb_Type.TabIndex = 12;
            this.lb_Type.Text = "Type";
            // 
            // textBox_Minute
            // 
            this.textBox_Minute.Location = new System.Drawing.Point(675, 175);
            this.textBox_Minute.Name = "textBox_Minute";
            this.textBox_Minute.Size = new System.Drawing.Size(171, 26);
            this.textBox_Minute.TabIndex = 13;
            // 
            // comboBox_Team
            // 
            this.comboBox_Team.FormattingEnabled = true;
            this.comboBox_Team.Location = new System.Drawing.Point(675, 214);
            this.comboBox_Team.Name = "comboBox_Team";
            this.comboBox_Team.Size = new System.Drawing.Size(171, 28);
            this.comboBox_Team.TabIndex = 14;
            this.comboBox_Team.SelectedIndexChanged += new System.EventHandler(this.comboBox_Team_SelectedIndexChanged_1);
            // 
            // comboBox_Player
            // 
            this.comboBox_Player.FormattingEnabled = true;
            this.comboBox_Player.Location = new System.Drawing.Point(677, 259);
            this.comboBox_Player.Name = "comboBox_Player";
            this.comboBox_Player.Size = new System.Drawing.Size(171, 28);
            this.comboBox_Player.TabIndex = 15;

            // 
            // comboBox_Type
            // 
            this.comboBox_Type.FormattingEnabled = true;
            this.comboBox_Type.Location = new System.Drawing.Point(677, 303);
            this.comboBox_Type.Name = "comboBox_Type";
            this.comboBox_Type.Size = new System.Drawing.Size(171, 28);
            this.comboBox_Type.TabIndex = 16;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(616, 375);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(98, 48);
            this.btn_Add.TabIndex = 17;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(748, 375);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(98, 48);
            this.btn_Delete.TabIndex = 18;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(397, 445);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(98, 48);
            this.btn_Insert.TabIndex = 19;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // dateTimePicker_MatchDate
            // 
            this.dateTimePicker_MatchDate.Location = new System.Drawing.Point(511, 26);
            this.dateTimePicker_MatchDate.Name = "dateTimePicker_MatchDate";
            this.dateTimePicker_MatchDate.Size = new System.Drawing.Size(293, 26);
            this.dateTimePicker_MatchDate.TabIndex = 20;
            this.dateTimePicker_MatchDate.ValueChanged += new System.EventHandler(this.dateTimePicke_Matchdate_ValueChanged);
            // 
            // InsertMatch_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(928, 566);
            this.Controls.Add(this.dateTimePicker_MatchDate);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.comboBox_Type);
            this.Controls.Add(this.comboBox_Player);
            this.Controls.Add(this.comboBox_Team);
            this.Controls.Add(this.textBox_Minute);
            this.Controls.Add(this.lb_Type);
            this.Controls.Add(this.lb_Player);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.lb_Minute);
            this.Controls.Add(this.dataGridView_InsertMatch);
            this.Controls.Add(this.comboBox_TeamAway);
            this.Controls.Add(this.comboBox_TeamHome);
            this.Controls.Add(this.textBox_MatchID);
            this.Controls.Add(this.lb_TeamAway);
            this.Controls.Add(this.lb_MatchDate);
            this.Controls.Add(this.lb_TeamHome);
            this.Controls.Add(this.lb_MatchID);
            this.Name = "InsertMatch_Form";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.InsertMatch_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_InsertMatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_MatchID;
        private System.Windows.Forms.Label lb_TeamHome;
        private System.Windows.Forms.Label lb_MatchDate;
        private System.Windows.Forms.Label lb_TeamAway;
        private System.Windows.Forms.TextBox textBox_MatchID;
        private System.Windows.Forms.ComboBox comboBox_TeamHome;
        private System.Windows.Forms.ComboBox comboBox_TeamAway;
        private System.Windows.Forms.DataGridView dataGridView_InsertMatch;
        private System.Windows.Forms.Label lb_Minute;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.Label lb_Player;
        private System.Windows.Forms.Label lb_Type;
        private System.Windows.Forms.TextBox textBox_Minute;
        private System.Windows.Forms.ComboBox comboBox_Team;
        private System.Windows.Forms.ComboBox comboBox_Player;
        private System.Windows.Forms.ComboBox comboBox_Type;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Insert;
        private System.Windows.Forms.DateTimePicker dateTimePicker_MatchDate;
    }
}

